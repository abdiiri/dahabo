import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2, MoreHorizontal, Trash2, Wallet } from "lucide-react";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/utils";
import { PageHeader } from "@/components/common/PageHeader";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatusPill } from "@/components/common/StatusPill";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AddCustomerTransactionDialog } from "@/components/staff/AddCustomerTransactionDialog";
import { RecordPaymentDialog } from "@/components/staff/RecordPaymentDialog";
import { listInvoices, type Invoice } from "@/lib/api/invoices";
import { listCustomers } from "@/lib/api/customers";
import {
  listCustomerTransactions,
  deleteCustomerTransaction,
  getTransactionStatus,
} from "@/lib/api/customer-transactions";
import type { Customer, CustomerTransaction } from "@/lib/api/types";
import {
  CUSTOMER_TRANSACTION_MODE_LABELS,
  CUSTOMER_TRANSACTION_STATUS_LABELS,
  CUSTOMER_TRANSACTION_TYPE_LABELS,
} from "@/lib/api/types";
import { usePermissions } from "@/lib/permissions";

type FinanceSearch = {
  tab?: "invoices" | "ledger" | undefined;
  customer?: string | undefined;
};

export const Route = createFileRoute("/staff/finance")({
  head: () => ({
    meta: [
      { title: "Finance | Dahabo Staff Portal" },
      { name: "description", content: "Invoices, receivables and the customer debt ledger." },
      { property: "og:title", content: "Finance | Dahabo Staff Portal" },
      {
        property: "og:description",
        content: "Invoices, receivables and the customer debt ledger.",
      },
    ],
  }),
  validateSearch: (search: Record<string, unknown>): FinanceSearch => {
    const rawTab = search["tab"];
    const rawCustomer = search["customer"];
    return {
      tab: rawTab === "ledger" ? "ledger" : rawTab === "invoices" ? "invoices" : undefined,
      customer: typeof rawCustomer === "string" ? rawCustomer : undefined,
    };
  },
  component: Page,
});

const INVOICE_STATUS_LABELS: Record<Invoice["status"], string> = {
  draft: "Draft",
  sent: "Sent",
  paid: "Paid",
  overdue: "Overdue",
  cancelled: "Cancelled",
};

const invoiceColumns: Column<Invoice>[] = [
  { key: "invoiceCode", header: "Invoice" },
  { key: "customerName", header: "Customer", render: (r) => r.customerName ?? "—" },
  {
    key: "issuedDate",
    header: "Issued",
    render: (r) => new Date(r.issuedDate).toLocaleDateString(),
  },
  {
    key: "dueDate",
    header: "Due",
    render: (r) => (r.dueDate ? new Date(r.dueDate).toLocaleDateString() : "—"),
  },
  { key: "amount", header: "Amount", render: (r) => `KSh ${r.amount.toLocaleString()}` },
  {
    key: "status",
    header: "Status",
    render: (r) => <StatusPill status={INVOICE_STATUS_LABELS[r.status]} />,
  },
];

function Page() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const { can } = usePermissions();
  const canEdit = can("customers", "edit");
  const canDelete = can("customers", "delete");

  const [tab, setTab] = useState<"invoices" | "ledger">(search.tab ?? "invoices");
  const [invoices, setInvoices] = useState<Invoice[] | null>(null);
  const [transactions, setTransactions] = useState<CustomerTransaction[] | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerFilter, setCustomerFilter] = useState<string>(search.customer ?? "all");
  const [paying, setPaying] = useState<CustomerTransaction | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    listInvoices().then((rows) => active && setInvoices(rows));
    listCustomers().then((rows) => active && setCustomers(rows));
    listCustomerTransactions().then((rows) => active && setTransactions(rows));
    return () => {
      active = false;
    };
  }, []);

  // Arriving from a link on the Customers tab (?tab=ledger&customer=<id>).
  useEffect(() => {
    if (search.tab) setTab(search.tab);
    if (search.customer) setCustomerFilter(search.customer);
  }, [search.tab, search.customer]);

  const customerNameById = useMemo(() => {
    const map = new Map<string, string>();
    customers.forEach((c) => map.set(c.id, c.name));
    return map;
  }, [customers]);

  const ledgerRows = useMemo(() => {
    const rows = transactions ?? [];
    if (customerFilter === "all") return rows;
    return rows.filter((t) => t.customerId === customerFilter);
  }, [transactions, customerFilter]);

  function goToTab(next: "invoices" | "ledger") {
    setTab(next);
    navigate({ search: (prev) => ({ ...prev, tab: next }) });
  }

  async function handleDeleteEntry() {
    if (!deletingId) return;
    if (!canDelete) {
      toast.error("You don't have permission to delete ledger entries");
      setDeletingId(null);
      return;
    }
    setBusyId(deletingId);
    try {
      await deleteCustomerTransaction(deletingId);
      setTransactions((rows) => (rows ?? []).filter((r) => r.id !== deletingId));
      // The deleted entry may have been reducing a customer's outstanding
      // balance — refresh so the Customers tab stays accurate.
      listCustomers().then(setCustomers);
      toast.success("Entry removed");
    } catch (err) {
      toast.error("Couldn't remove this entry", { description: getErrorMessage(err) });
    } finally {
      setBusyId(null);
      setDeletingId(null);
    }
  }

  const ledgerColumns: Column<CustomerTransaction>[] = [
    {
      key: "customerName",
      header: "Customer",
      render: (r) => r.customerName ?? customerNameById.get(r.customerId) ?? "—",
    },
    {
      key: "type",
      header: "Type",
      render: (r) => CUSTOMER_TRANSACTION_TYPE_LABELS[r.type],
    },
    { key: "amount", header: "Amount", render: (r) => `KSh ${r.amount.toLocaleString()}` },
    {
      key: "mode",
      header: "Mode",
      render: (r) => CUSTOMER_TRANSACTION_MODE_LABELS[r.mode],
    },
    { key: "date", header: "Date given", render: (r) => new Date(r.date).toLocaleDateString() },
    {
      key: "paidDate",
      header: "Date paid",
      render: (r) => (r.paidDate ? new Date(r.paidDate).toLocaleDateString() : "—"),
    },
    {
      key: "id",
      header: "Status",
      className: "w-px",
      render: (r) => (
        <StatusPill status={CUSTOMER_TRANSACTION_STATUS_LABELS[getTransactionStatus(r)]} />
      ),
    },
    {
      key: "id",
      header: "",
      className: "w-10",
      render: (r) => {
        const status = getTransactionStatus(r);
        const canPay = r.type === "debt" && status !== "settled";
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-8"
                disabled={busyId === r.id}
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              {canEdit && canPay ? (
                <DropdownMenuItem onSelect={() => setPaying(r)}>
                  <Wallet className="size-4" /> Record payment
                </DropdownMenuItem>
              ) : null}
              {canDelete ? (
                <DropdownMenuItem
                  onSelect={() => setDeletingId(r.id)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="size-4" /> Delete
                </DropdownMenuItem>
              ) : null}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  return (
    <>
      <PageHeader
        breadcrumb={["Staff", "Finance"]}
        title="Finance"
        description="Invoices, receivables, and the customer debt ledger."
        actions={
          tab === "ledger" && canEdit ? (
            <AddCustomerTransactionDialog
              onCreated={(row) => {
                setTransactions((rows) => [row, ...(rows ?? [])]);
                listCustomers().then(setCustomers);
              }}
            />
          ) : null
        }
      />

      <Tabs value={tab} onValueChange={(v) => goToTab(v as "invoices" | "ledger")}>
        <TabsList>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="ledger">Customer Ledger</TabsTrigger>
        </TabsList>

        <TabsContent value="invoices" className="mt-4">
          {invoices === null ? (
            <div className="flex min-h-[30vh] items-center justify-center text-muted-foreground">
              <Loader2 className="size-5 animate-spin" />
            </div>
          ) : (
            <DataTable
              data={invoices}
              columns={invoiceColumns}
              searchPlaceholder="Search invoices…"
            />
          )}
        </TabsContent>

        <TabsContent value="ledger" className="mt-4">
          {transactions === null ? (
            <div className="flex min-h-[30vh] items-center justify-center text-muted-foreground">
              <Loader2 className="size-5 animate-spin" />
            </div>
          ) : (
            <DataTable
              data={ledgerRows}
              columns={ledgerColumns}
              searchPlaceholder="Search the ledger…"
              toolbar={
                <Select
                  value={customerFilter}
                  onValueChange={(v) => {
                    setCustomerFilter(v);
                    navigate({
                      search: (prev) => ({ ...prev, customer: v === "all" ? undefined : v }),
                    });
                  }}
                >
                  <SelectTrigger className="w-[190px]">
                    <SelectValue placeholder="All customers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All customers</SelectItem>
                    {customers.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              }
            />
          )}
        </TabsContent>
      </Tabs>

      <RecordPaymentDialog
        entry={paying}
        onClose={() => setPaying(null)}
        onSaved={(updated) => {
          setTransactions((rows) => (rows ?? []).map((r) => (r.id === updated.id ? updated : r)));
          listCustomers().then(setCustomers);
          setPaying(null);
        }}
      />

      <AlertDialog open={deletingId !== null} onOpenChange={(open) => !open && setDeletingId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this ledger entry?</AlertDialogTitle>
            <AlertDialogDescription>
              This moves it to the Recycle Bin and re-totals the customer's outstanding balance. It
              can be restored later from there.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteEntry}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
